Please check this dataset for the contents here.
https://www.kaggle.com/datasets/mhyodo/otto-makotu-models